// src/Auth/Auth.js

import auth0 from 'auth0-js'
import history from '../history'

// console.log(process.env)
// console.log('RAAD:', process.env.REACT_APP_AUZ_DOMAIN)
// console.log('TEST:', process.env.PORT)

export default class Auth {
  accessToken
  idToken
  expiresAt

  // ¡MEDECINO PELIGROSO!
  auth0 = new auth0.WebAuth({
    domain: 'beyondnapavalley.auth0.com',
    clientID: 'Oaph33YXjfkEcdVIrE7YT6qeksUt03dy',
    redirectUri: 'http://localhost:3000/callback',
    responseType: 'token id_token',
    scope: 'openid profile'
  });

  constructor() {

    // if (localStorage.getItem("accessToken") && localStorage.getItem("idToken") && localStorage.getItem("expiresAt")) {
    //   console.log("Auth.js.constructor() IF - Data found in the localStorage");
    //   this.accessToken = localStorage.getItem("accessToken");
    //   this.idToken = localStorage.getItem("idToken");
    //   this.expiresAt = localStorage.getItem("expiresAt");
    // }
    // else {
    //   console.log("Auth.js.constructor() ELSE - No data found in the localstorage ELSE");
    // }

    this.login = this.login.bind(this)
    this.logout = this.logout.bind(this)
    this.handleAuthentication = this.handleAuthentication.bind(this)
    this.isAuthenticated = this.isAuthenticated.bind(this)
    this.getAccessToken = this.getAccessToken.bind(this)
    this.getIdToken = this.getIdToken.bind(this)
    this.renewSession = this.renewSession.bind(this)

    //this.userProfile = this.userProfile.bind(this)
    this.parseJWT = this.parseJWT.bind(this)
  }

  handleAuthentication() {

    //var wm = new WeakMap() // Hold the auth info...

    this.auth0.parseHash((err, authResult) => {
      if (authResult && authResult.accessToken && authResult.idToken) {
        this.setSession(authResult)
        
        // this.getUserInfo(authResult.idToken, function(error, profile) {
        //   if (error)
        //     return
        //   console.log('profile', profile)
        // })

      } else if (err) {
        history.replace('/main');
        console.log(err);
        alert(`Error: ${err.error}. Check the console for further details.`);
      }
    });

    //wm.set( pri)
    

  }

  getAccessToken() {
    return this.accessToken
  }

  getIdToken() {
    return this.idToken
  }

  setSession(authResult) {
    //console.log("Auth.js.setSession() called with : authResult ->", authResult);
    
    // Set isLoggedIn flag in localStorage
    localStorage.setItem('isLoggedIn', 'true');

    // Set the time that the Access Token will expire at
    let expiresAt = (authResult.expiresIn * 1000) + new Date().getTime();
    this.accessToken = authResult.accessToken;
    this.idToken = authResult.idToken;
    this.expiresAt = expiresAt;

    console.log(this.parseJWT(this.idToken)['name'])
    //getUserInfo(this.idToken)

    // wot?  Why is this going into localstorage?!
    // localStorage.setItem("accessToken", authResult.accessToken);
    // localStorage.setItem("idToken", authResult.idToken);
    // localStorage.setItem("expiresAt", (new Date().getTime() / 1000) + authResult.expiresIn);
    // localStorage.setItem("isLoggedIn", true);

    // navigate to the home route
    history.replace('/dashboard');
  }

  parseJWT(token) {
    //function parseJwt (token) {
        var base64Url = token.split('.')[1]
        var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/')
        var jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''))

        return JSON.parse(jsonPayload)
    //};
  }

  renewSession() {
    this.auth0.checkSession({}, (err, authResult) => {
       //alert('renewsession()')
       if (authResult && authResult.accessToken && authResult.idToken) {
         this.setSession(authResult);
       } else if (err) {
         this.logout();
         //console.log(err);
         //alert(`Could not get a new token (${err.error}: ${err.error_description}).`);
       }
    });
  }

  login() {
    this.auth0.authorize()

    // const accessToken = this.getAccessToken()
    // console.log(`getProfile:accessToken: ${accessToken}`)
  }

  logout() {
    //alert('logout!')
    // Remove tokens and expiry time
    this.accessToken = null;
    this.idToken = null;
    this.expiresAt = 0;

    // Remove isLoggedIn flag from localStorage
    localStorage.removeItem('isLoggedIn');

    this.auth0.logout({
      returnTo: window.location.origin
    });

    // navigate to the home route
    history.replace('/checkin');
  }

  isAuthenticated() {
    // Check whether the current time is past the
    // access token's expiry time
    let expiresAt = this.expiresAt;
    return new Date().getTime() < expiresAt;
  }

  // DK -- SOME ADDITIONAL FUNCTIONS TO GET USER 
  // DATA AFTER LOGIN
  // getProfile() {
  //   if (!userProfile) {
  //     if (!accessToken) {
  //       console.error('Access Token must exist to fetch profile')
  //     }

  //     webAuth.client.userInfo(accessToken, function(err, profile) {
  //      if (profile) {
  //        userProfile = profile
  //        displayProfile()
  //      }
  //     })
  //   } else {
  //     displayProfile()
  //   }
  // } // getProfile

  // displayProfile() {
  //   // Display the profile
  //   document.querySelector('#profile-view .nickname').innerHTML = userProfile.nickname
  //   document.querySelector('#profile-view .full-profile').innerHTML = JSON.stringify(userProfile, null, 2)
  //   document.querySelector('#profile-view img').src = userProfile.picture
  // } // displayProfile
} // class